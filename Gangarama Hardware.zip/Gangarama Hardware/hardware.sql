-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 19, 2020 at 06:05 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hardware`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `cus_id` varchar(100) NOT NULL,
  `cus_name` varchar(100) NOT NULL,
  `cus_contact_number` varchar(100) NOT NULL,
  `cus_addres` varchar(100) NOT NULL,
  `cus_nic` varchar(100) NOT NULL,
  `cus_email` varchar(100) NOT NULL,
  PRIMARY KEY (`cus_id`),
  KEY `cus_contact_number` (`cus_contact_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cus_id`, `cus_name`, `cus_contact_number`, `cus_addres`, `cus_nic`, `cus_email`) VALUES
('CUS-23-0001', 'chana', '6541', 'kjhk', '651', 'kuhgk');

-- --------------------------------------------------------

--
-- Table structure for table `good_received_note`
--

DROP TABLE IF EXISTS `good_received_note`;
CREATE TABLE IF NOT EXISTS `good_received_note` (
  `no` int(100) NOT NULL AUTO_INCREMENT,
  `grn_number` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `sup_id` varchar(100) NOT NULL,
  `inventory_name` varchar(100) NOT NULL,
  `inventory_id` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `cost_price` int(100) NOT NULL,
  PRIMARY KEY (`no`),
  KEY `sup_id` (`sup_id`,`inventory_id`),
  KEY `good_received_note_ibfk_1` (`inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `good_received_note`
--

INSERT INTO `good_received_note` (`no`, `grn_number`, `date`, `sup_id`, `inventory_name`, `inventory_id`, `quantity`, `cost_price`) VALUES
(1, 'GRN-23-0001', '2020-07-23', 'SUP-23-0001', 'gray 001', 'INV-23-0001', 50, 10),
(2, 'GRN-23-0002', '2020-07-23', 'SUP-23-0001', 'gray 001', 'INV-23-0001', 5, 80);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE IF NOT EXISTS `inventory` (
  `sup_id` varchar(100) NOT NULL,
  `inventory_type` varchar(100) NOT NULL,
  `inventory_id` varchar(100) NOT NULL,
  `inventory_name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `receive` int(100) DEFAULT NULL,
  `issu` int(100) DEFAULT NULL,
  `closing` int(100) DEFAULT NULL,
  PRIMARY KEY (`inventory_id`),
  KEY `sup_id` (`sup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`sup_id`, `inventory_type`, `inventory_id`, `inventory_name`, `location`, `receive`, `issu`, `closing`) VALUES
('SUP-23-0001', 'paint', 'INV-23-0001', 'gray 001', 'rakke 3', 5, NULL, 110),
('SUP-23-0001', 'nut', 'INV-23-0002', 'agal 2 1/2', 'boathale 3', NULL, NULL, NULL),
('SUP-23-0001', 'rim', 'INV-23-0003', 'blue 454', 'rakka 32', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
CREATE TABLE IF NOT EXISTS `invoice` (
  `invoice_no` int(100) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `cus_id` varchar(100) NOT NULL,
  `inventory_name` varchar(100) NOT NULL,
  `inventory_id` varchar(100) NOT NULL,
  `cost_price` varchar(100) NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  PRIMARY KEY (`invoice_no`),
  KEY `cus_id` (`cus_id`,`inventory_id`),
  KEY `invoice_ibfk_1` (`inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE IF NOT EXISTS `supplier` (
  `sup_id` varchar(100) NOT NULL,
  `sup_name` varchar(100) NOT NULL,
  `sup_contact_number` varchar(100) NOT NULL,
  `sup_address` varchar(100) NOT NULL,
  `sup_email` varchar(100) NOT NULL,
  `sup_nic` int(100) NOT NULL,
  PRIMARY KEY (`sup_id`),
  KEY `sup_contact_number` (`sup_contact_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sup_id`, `sup_name`, `sup_contact_number`, `sup_address`, `sup_email`, `sup_nic`) VALUES
('SUP-23-0001', 'seeya', '55', 'hytfjg', 'ljyjkiugh', 89);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `password`, `telephone`, `email`) VALUES
('1', '1', '5646', 'jgfv'),
('2', '123456789', 'chanahgg', 'jh');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `good_received_note`
--
ALTER TABLE `good_received_note`
  ADD CONSTRAINT `good_received_note_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `good_received_note_ibfk_2` FOREIGN KEY (`sup_id`) REFERENCES `supplier` (`sup_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`sup_id`) REFERENCES `supplier` (`sup_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`cus_id`) REFERENCES `customer` (`cus_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
