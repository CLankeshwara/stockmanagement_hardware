﻿Public Class help
    Private Sub btnback_Click(sender As Object, e As EventArgs) Handles btnback.Click
        mainmenu.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class