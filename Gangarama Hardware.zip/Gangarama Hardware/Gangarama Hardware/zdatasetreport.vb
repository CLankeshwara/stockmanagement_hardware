﻿

Partial Public Class zdatasetreport
    Partial Public Class inventory_rDataTable
        Private Sub inventory_rDataTable_inventory_rRowChanging(sender As Object, e As inventory_rRowChangeEvent) Handles Me.inventory_rRowChanging

        End Sub

    End Class
End Class
