-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 16, 2020 at 07:34 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hardware`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `cus_id` varchar(100) NOT NULL,
  `cus_name` varchar(15) NOT NULL,
  `cus_contact_number` varchar(13) NOT NULL,
  `cus_addres` varchar(50) NOT NULL,
  `cus_nic` varchar(13) NOT NULL,
  `cus_email` varchar(100) NOT NULL,
  PRIMARY KEY (`cus_id`),
  UNIQUE KEY `cus_name` (`cus_name`),
  KEY `cus_contact_number` (`cus_contact_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cus_id`, `cus_name`, `cus_contact_number`, `cus_addres`, `cus_nic`, `cus_email`) VALUES
('CUS-12-0001', 'bagya', '0112886679', 'matiishuddagara road werahara', '77666889900', 'sample17@sample.com'),
('CUS-16-0004', 'mr nawageewana', '0112886677', '1st lane,werahara', '77666889990', 'sample122@sample.com'),
('CUS-28-0002', 'thariya', '0112886666', 'kahataahawtahtha road werahara', '77666889977', 'sample112@sample.com');

-- --------------------------------------------------------

--
-- Table structure for table `good_received_note`
--

DROP TABLE IF EXISTS `good_received_note`;
CREATE TABLE IF NOT EXISTS `good_received_note` (
  `no` int(100) NOT NULL AUTO_INCREMENT,
  `grn_number` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `sup_id` varchar(100) NOT NULL,
  `inventory_name` varchar(100) NOT NULL,
  `inventory_id` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `cost_price` int(100) NOT NULL,
  PRIMARY KEY (`no`),
  KEY `sup_id` (`sup_id`,`inventory_id`),
  KEY `good_received_note_ibfk_1` (`inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `good_received_note`
--

INSERT INTO `good_received_note` (`no`, `grn_number`, `date`, `sup_id`, `inventory_name`, `inventory_id`, `quantity`, `cost_price`) VALUES
(4, 'GRN-16-0001', '2020-09-01', 'SUP-16-0001', 'dulax Laker', 'INV-16-0001', 9, 90),
(5, 'GRN-16-0001', '2020-09-01', 'SUP-16-0001', 'water base', 'INV-16-0001', 7, 70),
(6, 'GRN-16-0002', '2020-09-16', 'SUP-16-0001', 'water base', 'INV-16-0001', 78, 89),
(7, 'GRN-16-0002', '2020-09-16', 'SUP-16-0001', 'water seal', 'INV-16-0001', 770, 89),
(8, 'GRN-16-0003', '2020-09-16', 'SUP-16-0001', 'water seal', 'INV-16-0003', 8789, 90),
(9, 'GRN-16-0003', '2020-09-16', 'SUP-16-0001', 'water base', 'INV-16-0002', 76, 780),
(10, 'GRN-17-0001', '2020-09-17', 'SUP-16-0001', 'dulax Laker', 'INV-16-0001', 70, 90);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE IF NOT EXISTS `inventory` (
  `sup_id` varchar(100) NOT NULL,
  `inventory_type` varchar(100) NOT NULL,
  `inventory_id` varchar(100) NOT NULL,
  `inventory_name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `receive` int(100) DEFAULT NULL,
  `issu` int(100) DEFAULT NULL,
  `closing` int(100) DEFAULT NULL,
  PRIMARY KEY (`inventory_id`),
  KEY `sup_id` (`sup_id`),
  KEY `inventory_name` (`inventory_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`sup_id`, `inventory_type`, `inventory_id`, `inventory_name`, `location`, `receive`, `issu`, `closing`) VALUES
('SUP-16-0001', 'paint', 'INV-16-0001', 'dulax Laker', '56', 70, 7, 163),
('SUP-16-0001', 'paint', 'INV-16-0002', 'water base', '66', 7, NULL, 7),
('SUP-16-0001', 'paint', 'INV-16-0003', 'water seal', '45', 8789, NULL, 8882);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
CREATE TABLE IF NOT EXISTS `invoice` (
  `invoice_no` int(100) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `cus_id` varchar(100) NOT NULL,
  `inventory_name` varchar(100) NOT NULL,
  `inventory_id` varchar(100) NOT NULL,
  `cost_price` varchar(100) DEFAULT NULL,
  `Quantity` varchar(100) NOT NULL,
  PRIMARY KEY (`invoice_no`),
  KEY `cus_id` (`cus_id`,`inventory_id`),
  KEY `invoice_ibfk_1` (`inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_no`, `bill_no`, `date`, `cus_id`, `inventory_name`, `inventory_id`, `cost_price`, `Quantity`) VALUES
(1, 'INVOICE-16-0001', '2020-09-16', 'CUS-12-0001', 'dulax Laker', 'INV-16-0001', '90', '9'),
(2, 'INVOICE-16-0002', '2020-09-16', 'CUS-12-0001', 'dulax Laker', 'INV-16-0001', '90', '70'),
(3, 'INVOICE-17-0001', '2020-09-17', 'CUS-16-0004', 'water seal', 'INV-16-0003', '800', '70'),
(4, 'INVOICE-17-0001', '2020-09-17', 'CUS-16-0004', 'water seal', 'INV-16-0003', '90', '8'),
(5, 'INVOICE-17-0002', '2020-09-17', 'CUS-12-0001', 'water base', 'INV-16-0002', '10', '1');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE IF NOT EXISTS `supplier` (
  `sup_id` varchar(100) NOT NULL,
  `sup_name` varchar(15) NOT NULL,
  `sup_contact_number` varchar(13) NOT NULL,
  `sup_address` varchar(50) NOT NULL,
  `sup_email` varchar(25) NOT NULL,
  `sup_nic` varchar(13) NOT NULL,
  PRIMARY KEY (`sup_id`),
  UNIQUE KEY `sup_name` (`sup_name`),
  KEY `sup_contact_number` (`sup_contact_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sup_id`, `sup_name`, `sup_contact_number`, `sup_address`, `sup_email`, `sup_nic`) VALUES
('SUP-16-0001', 'jonny hardware', '88776678', 'waththegedara,werahara', 'example1@sample.com', '66789'),
('SUP-16-0002', 'nawalok', '77989809', 'piliyandala road kasbawa', 'sample5@gmail.com', '87687798');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `password`, `telephone`, `email`) VALUES
('1', '1', '5646', 'jgfv'),
('admin', 'admin12345', '01123456789', 'example1@gmail.com');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `good_received_note`
--
ALTER TABLE `good_received_note`
  ADD CONSTRAINT `good_received_note_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `good_received_note_ibfk_2` FOREIGN KEY (`sup_id`) REFERENCES `supplier` (`sup_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`sup_id`) REFERENCES `supplier` (`sup_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`cus_id`) REFERENCES `customer` (`cus_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
